<?php 
get_header();

/* Template Name:Contact Page */ 
?>
<?php $about_banner_image=get_field( 'contact_banner_image' ); 
$front_page_id = get_option('page_on_front'); 
 $a_main_title=get_field( 'a_main_title' );
 $about_image=get_field( 'about_image' );
 $about_details=get_field( 'about_details' );
 $address=get_field( 'address' );
 $number=get_field( 'number' );
 $email=get_field( 'email' );
 $add_gooogle_map=get_field( 'add_gooogle_map' );
?>

<div class="heading-banner-area overlay-bg" style="background-image: url('<?php echo $about_banner_image['url'] ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading-banner">
                    <div class="heading-banner-title">
                        <h2><?php echo get_the_title(); ?></h2>
                    </div>
                    <div class="breadcumbs pb-15">
                        <ul>
                            <li><a href="<?php echo site_url(); ?>"><?php echo get_the_title($front_page_id); ?></a></li>
                            <li><?php echo get_the_title(); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="contact-us-area  pt-80 pb-80">
        <div class="container">	
            <div class="contact-us customer-login bg-white">
                <div class="row">
                    <div class="col-lg-4 col-md-5">
                        <div class="contact-details">
                            <h4 class="title-1 title-border text-uppercase mb-30">contact details</h4>
                            <ul>
                                <?php if($address): ?>
                                <li>
                                    <i class="zmdi zmdi-pin"></i>
                                    <span><?php echo $address; ?></span>
                                   
                                </li>
                                <?php endif; ?>
                                <li>
                                    <i class="zmdi zmdi-phone"></i>
                                    <span><a href="tel:<?php echo  preg_replace('/[^0-9]/', '', $f_number); ?>"><?php echo $number; ?></a></span>
                                  
                                </li>
                                <?php if($email): ?>
                                        <li>
                                            <i class="zmdi zmdi-email"></i>
                                            <span><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></span>
                                        
                                        </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="send-message mt-60">
                        <div class="container">
   <div class="text">Contact us Form</div>
   <div class="container">
   <div class="text">Contact us Form</div>
   <form id="contactForm" enctype="multipart/form-data">
      <?php wp_nonce_field('contact_form_nonce', 'security'); ?>
      <div class="form-row">
         <div class="input-data">
            <input type="text" name="first_name" required>
            <div class="underline"></div>
            <label for="first_name">First Name</label>
         </div>
         <div class="input-data">
            <input type="text" name="last_name" required>
            <div class="underline"></div>
            <label for="last_name">Last Name</label>
         </div>
      </div>
      <div class="form-row">
         <div class="input-data">
            <input type="email" name="email_address" required>
            <div class="underline"></div>
            <label for="email_address">Email Address</label>
         </div>
         <div class="input-data">
            <input type="text" name="website_name" required>
            <div class="underline"></div>
            <label for="website_name">Website Name</label>
         </div>
      </div>
      <div class="form-row">
         <div class="input-data textarea">
            <textarea name="message" rows="8" cols="80" required></textarea>
            <div class="underline"></div>
            <label for="message">Write your message</label>
         </div>
      </div>
      <div class="form-row">
         <div class="input-data">
            <input type="file" name="pdf_file" accept=".pdf" required>
            <label for="pdf_file">Upload PDF</label>
         </div>
      </div>
      <div class="form-row">
         <div class="input-data">
            <input type="file" name="image_file" accept="image/*" required>
            <label for="image_file">Upload Image</label>
         </div>
      </div>
      <div class="form-row submit-btn">
         <div class="input-data">
            <input type="submit" value="Submit">
         </div>
         <!-- Loader container -->
         <div id="loader" style="display:none;">
            <img src="https://aashu-freelancer.great-site.net/wp-content/uploads/2024/09/Glass-lines.gif" alt="Loading...">
         </div>
         <!-- Response message -->
         <div id="response"></div>
      </div>
   </form>
</div>

                </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-7 mt-xs-30">
                        <?php if($add_gooogle_map): ?>
                            <div class="map-area">
                                    <?php echo $add_gooogle_map; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
   $(document).ready(function () {
      $('#contactForm').on('submit', function (e) {
         e.preventDefault(); // Prevent form submission

         // Show the loader
         $('#loader').show();

         var formData = new FormData(this);
         formData.append('action', 'handle_contact_form'); // Add action parameter
         formData.append('security', $('#security').val()); // Add nonce

         $.ajax({
            type: 'POST',
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
               // Hide the loader
               $('#loader').hide();

               if (response.success) {
                  $('#response').html('<div class="success">Form successfully submitted!</div>');
               } else {
                  $('#response').html('<div class="error">Error: ' + response.data + '</div>');
               }
            },
            error: function () {
               // Hide the loader
               $('#loader').hide();

               $('#response').html('<div class="error">There was an error submitting the form.</div>');
            }
         });
      });
   });
</script>

<?php get_footer(); ?>