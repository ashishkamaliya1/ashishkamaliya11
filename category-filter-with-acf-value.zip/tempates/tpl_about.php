<?php 
get_header();

/* Template Name:about Page */ 
?>
<?php $about_banner_image=get_field( 'about_banner_image' ); 
$front_page_id = get_option('page_on_front'); 
 $a_main_title=get_field( 'a_main_title' );
 $about_image=get_field( 'about_image' );
 $about_details=get_field( 'about_details' );
?>

<div class="heading-banner-area overlay-bg" style="background-image: url('<?php echo $about_banner_image['url'] ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading-banner">
                    <div class="heading-banner-title">
                        <h2><?php echo get_the_title(); ?></h2>
                    </div>
                    <div class="breadcumbs pb-15">
                        <ul>
                            <li><a href="<?php echo site_url(); ?>"><?php echo get_the_title($front_page_id); ?></a></li>
                            <li><?php echo get_the_title(); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="about-us-area  pt-80 pb-80">
    <div class="container">	
        <div class="about-us bg-white">
            <div class="row">
                <div class="col-lg-6">
                    <?php if($about_image): ?>
                        <div class="about-photo">
                            <img src="<?php echo $about_image['url']; ?>" alt="">
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <div class="about-brief bg-dark-white">
                        <h4 class="title-1 title-border text-uppercase mb-30"><?php echo $a_main_title; ?></h4>
                        <?php echo $about_details; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>