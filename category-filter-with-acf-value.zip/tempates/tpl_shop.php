<?php 
get_header();

/* Template Name:Shop Page */ 
?>
<?php $about_banner_image=get_field( 'about_banner_image' ); 
$front_page_id = get_option('page_on_front'); 
 $a_main_title=get_field( 'a_main_title' );
 $about_image=get_field( 'about_image' );
 $about_details=get_field( 'about_details' );
?>

<div class="heading-banner-area overlay-bg" style="background-image: url('<?php echo $about_banner_image['url'] ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading-banner">
                    <div class="heading-banner-title">
                        <h2><?php echo get_the_title(); ?></h2>
                    </div>
                    <div class="breadcumbs pb-15">
                        <ul>
                            <li><a href="<?php echo site_url(); ?>"><?php echo get_the_title($front_page_id); ?></a></li>
                            <li><?php echo get_the_title(); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
$categories = get_terms( array(
    'taxonomy' => 'product-categories',
    'hide_empty' => false,
) );
?>
<div class="purchase-online-area pt-80">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title text-center"></div>
            </div>
        </div>
        <div class="row">
    <div class="col-lg-12 text-center">
        <!-- Nav tabs -->
        <ul class="tab-menu nav clearfix">
            <li><a class="active" data-category="all" data-bs-toggle="tab">All Category</a></li>
            <?php foreach ($categories as $term) { ?>
                <li><a class="" data-category="<?php echo esc_attr($term->slug); ?>" data-bs-toggle="tab"><?php echo esc_html($term->name); ?></a></li>
            <?php } ?>
        </ul>

        <?php 
        // Fetch ACF field object
        $field = get_field_object('field_66ec10ade0d74');
        if ($field) {
            $value = $field['value'];
            $label = $field['label'];

            echo '<label for="acf-select">' . esc_html($label) . '</label>';
            echo '<select id="acf-select" class="form-select" aria-label="Select an option">';
            foreach ($field['choices'] as $key => $choice) {
                $selected = ($key === $value) ? ' selected' : '';
                echo '<option value="' . esc_attr($key) . '"' . $selected . '>' . esc_html($choice) . '</option>';
            }
            echo '</select>';
        } else {
            echo 'No value selected.';
        }
        ?>
    </div>
    
    <div class="col-lg-12">
        <!-- Tab panes -->
        <div class="tab-content">
            <div class="tab-pane active" id="new-arrivals">
                <div class="row append-content-row"></div>
                <div class="text-center mt-4">
                    <button class="btn btn-primary load-more-btn">Load More</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
(function($) {
    $(document).ready(function() {
        var offset = 0;
        var limit = 8;
        var category = 'all';
        var selectedValue = $('#acf-select').val();

        // Load initial products
        loadProducts(category, offset, limit, selectedValue);

        // Load products when category tab is clicked
        $('.tab-menu a').on('click', function(e) {
            e.preventDefault();
            category = $(this).data('category');
            offset = 0;
            loadProducts(category, offset, limit, selectedValue);
        });

        // Load more products when "Load More" button is clicked
        $('.load-more-btn').on('click', function(e) {
            e.preventDefault();
            offset += limit;
            loadProducts(category, offset, limit, selectedValue);
        });

        // Update selected value on change
        $('#acf-select').on('change', function() {
            selectedValue = $(this).val();
            offset = 0; // Reset offset
            loadProducts(category, offset, limit, selectedValue);
        });

        function loadProducts(category, offset, limit, selectedValue) {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'filter_products',
                    category: category,
                    offset: offset,
                    limit: limit,
                    selected_value: selectedValue
                },
                beforeSend: function() {
                    $('.append-content-row').html('<div class="loader">Loading...</div>');
                },
                success: function(response) {
                    if (response.success) {
                        if (offset === 0) {
                            $('.append-content-row').html(response.data.html);
                        } else {
                            $('.append-content-row').append(response.data.html);
                        }
                        $('.load-more-btn').toggle(response.data.has_more);
                    } else {
                        $('.append-content-row').html('<div class="error">No products found.</div>');
                    }
                },
                error: function() {
                    $('.append-content-row').html('<div class="error">An error occurred. Please try again.</div>');
                }
            });
        }
    });
})(jQuery);
</script>

<?php get_footer(); ?>