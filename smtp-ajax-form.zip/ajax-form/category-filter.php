<?php


function my_enqueue_scripts() {
    // Enqueue your JavaScript file
    wp_enqueue_script('my-ajax-script', get_template_directory_uri() . '/js/ajax-script.js', array('jquery'), null, true);
    wp_localize_script('my-ajax-script', 'ajaxurl', admin_url('admin-ajax.php'));
}
add_action('wp_enqueue_scripts', 'my_enqueue_scripts');

function filter_products() {
    $offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
    $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 8;
    $category_slug = isset($_POST['category']) ? sanitize_text_field($_POST['category']) : 'all';

    // Query arguments
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $limit,
        'offset' => $offset,
    );

    // Filter by category if not 'all'
    if ($category_slug !== 'all') {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product-categories',
                'field' => 'slug',
                'terms' => $category_slug,
            ),
        );
    }

    $query = new WP_Query($args);
    $products_html = '';
    $has_more = false;

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $price = get_field('price') ? '$' . esc_html(get_field('price')) : 'Price not available';

            $products_html .= '<div class="single-product col-xl-3 col-lg-4 col-md-6">
                <div class="product-img">
                    <span class="pro-label new-label">New</span>
                    <a href="' . esc_url(get_permalink()) . '">
                        <img src="' . esc_url(get_the_post_thumbnail_url() ?: DEFAULT_IMG) . '" alt="' . esc_attr(get_the_title()) . '">
                    </a>
                </div>
                <div class="product-info clearfix">
                    <h4 class="post-title"><a href="' . esc_url(get_permalink()) . '">' . esc_html(get_the_title()) . '</a></h4>
                    <span class="pro-price">' . $price . '</span>
                </div>
            </div>';
        }
        $has_more = $query->found_posts > ($offset + $limit);
    } else {
        $products_html = '<div>No products found.</div>';
    }

    wp_reset_postdata();

    // Return a JSON response
    wp_send_json_success(array(
        'html' => $products_html,
        'has_more' => $has_more,
    ));
}

add_action('wp_ajax_filter_products', 'filter_products');
add_action('wp_ajax_nopriv_filter_products', 'filter_products');
