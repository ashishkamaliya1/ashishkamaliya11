<?php 
get_header();

/* Template Name:Shop Page */ 
?>
<?php $about_banner_image=get_field( 'about_banner_image' ); 
$front_page_id = get_option('page_on_front'); 
 $a_main_title=get_field( 'a_main_title' );
 $about_image=get_field( 'about_image' );
 $about_details=get_field( 'about_details' );
?>

<div class="heading-banner-area overlay-bg" style="background-image: url('<?php echo $about_banner_image['url'] ?>');">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading-banner">
                    <div class="heading-banner-title">
                        <h2><?php echo get_the_title(); ?></h2>
                    </div>
                    <div class="breadcumbs pb-15">
                        <ul>
                            <li><a href="<?php echo site_url(); ?>"><?php echo get_the_title($front_page_id); ?></a></li>
                            <li><?php echo get_the_title(); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
$categories = get_terms( array(
    'taxonomy' => 'product-categories',
    'hide_empty' => false,
) );
?>
<div class="purchase-online-area pt-80">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title text-center"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center">
                <!-- Nav tabs -->
                <ul class="tab-menu nav clearfix">
                    <li><a class="active" data-category="all" data-bs-toggle="tab">All Category</a></li>
                    <?php foreach ( $categories as $term ) { ?>
                        <li><a class="" data-category="<?php echo $term->slug; ?>" data-bs-toggle="tab"><?php echo $term->name ?></a></li>
                    <?php }; ?>
                </ul>
            </div>
            <div class="col-lg-12">
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="new-arrivals">
                        <div class="row append-content-row"></div>
                        <div class="text-center mt-4">
                            <button class="btn btn-primary load-more-btn">Load More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- PURCHASE-ONLINE-AREA END -->

<script type="text/javascript">
(function($) {
    jQuery(document).ready(function($) {
        var offset = 0;
        var limit = 8;
        var category = 'all';

        // Load initial products
        loadProducts(category, offset, limit);

        // Load products when category tab is clicked
        $('.tab-menu a').on('click', function(e) {
            e.preventDefault();

            // Reset offset and category
            category = $(this).attr('data-category');
            offset = 0;

            // Load products for the selected category
            loadProducts(category, offset, limit);
        });

        // Load more products when "Load More" button is clicked
        $('.load-more-btn').on('click', function(e) {
            e.preventDefault();

            // Increment the offset to load the next set of products
            offset += limit;
            loadProducts(category, offset, limit);
        });

        function loadProducts(category, offset, limit) {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'filter_products',
                    category: category,
                    offset: offset,
                    limit: limit
                },
                beforeSend: function() {
                    if (offset === 0) {
                        // Show loading indicator when loading new categories
                        $('.append-content-row').html('<div class="loader">Loading...</div>');
                    } else {
                        // Show loader below the current products when "Load More" is clicked
                        $('.load-more-btn').text('Loading...').prop('disabled', true);
                    }
                },
                success: function(response) {
                    if (response.success) {
                        if (offset === 0) {
                            // Replace the content with products
                            $('.append-content-row').html(response.data.html);
                        } else {
                            // Append the new products to the existing ones
                            $('.append-content-row').append(response.data.html);
                        }

                        // Re-enable the "Load More" button
                        $('.load-more-btn').text('Load More').prop('disabled', false);

                        // Show or hide the "Load More" button based on availability
                        if (response.data.has_more) {
                            $('.load-more-btn').show();
                        } else {
                            $('.load-more-btn').hide();
                        }
                    } else {
                        $('.append-content-row').html('<div class="error">No products found.</div>');
                    }
                },
                error: function() {
                    $('.append-content-row').html('<div class="error">An error occurred. Please try again.</div>');
                }
            });
        }
    });
})(jQuery);
</script>

<?php get_footer(); ?>