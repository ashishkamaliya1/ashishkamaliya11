<?php 

function enqueue_custom_scripts()
{ 
	$reviews_per_page = get_field('reviews_per_page' , 'option');;
	
	wp_enqueue_script('custom-scripts', get_stylesheet_directory_uri() . '/assets/js/ajax-script.js', true);
	wp_localize_script('custom-scripts', 'acfFieldData', array('reviews_per_page' => $reviews_per_page));
	wp_localize_script('custom-scripts', 'frontendajax', array('ajaxurl' => admin_url('admin-ajax.php')));

}
add_action('wp_enqueue_scripts', 'enqueue_custom_scripts');

function reviews_load_more_posts()
{

	$page = $_POST['page'];
    $loop_posts_per_page = $_POST['loop_posts_per_page_loop'];
    $category_id_1 = isset($_POST['id1']) ? sanitize_text_field($_POST['id1']) : '';
    $category_id_2 = isset($_POST['id2']) ? sanitize_text_field($_POST['id2']) : '';

    $args = array(
        'post_type'      => 'all-testimonials',
        'post_status'    => 'publish',
		'order' => 'DESC',
        'posts_per_page'=> $loop_posts_per_page,
		'paged'          => $page,
		'meta_query'      => array(
            'relation' => 'AND',
        ),                
    );
	

	if ($category_id_1) {
        $args['meta_query'][] = array(
            'key' => 'select_country', // Replace with your first taxonomy name
            'value'    => $category_id_1,
            'compare' => '='
        );
    }

	if ($category_id_2) {
        $args['meta_query'][] = array(
            'key' => 'select_programmme', // Replace with your first taxonomy name
            'value'    => $category_id_2,
            'compare' => '='
        );
    }

	if (empty($category_id_1) && empty($category_id_2)) {
        foreach ($args['meta_query'] as $index => $meta_query) {
            if (isset($meta_query['key']) && ($meta_query['key'] === 'select_country' || $meta_query['key'] === 'select_programmme')) {
                unset($args['meta_query'][$index]);
            }
        }
    }

    $loop = new WP_Query($args);
    $content = '';
    $found_posts = $loop->found_posts;
	$max_pages = $loop->max_num_pages;
	$class = '';
	$big = '';
	$count = 1;

    if ($loop->have_posts()) {
        while ($loop->have_posts()) : $loop->the_post();
			$id = get_the_ID(  );
			$image = get_field('image_video_image' , $id);
			$youtube_id = get_field('youtube_id' , $id);
			$location_name = get_field( 'location_name' , $id );
			$programme_name = get_field( 'programme_name' , $id );
			$details = get_field( 'details' , $id );
			$learners_profile_image = get_field( 'learners_profile_image' , $id );
			
			if($image || $youtube_id || $details || $location_name || $learners_profile_image || $programme_name) :
				$content .= testimonial_data($youtube_id, $image, $details, $location_name, $programme_name, $learners_profile_image,$count);
			endif;
			$count++;
        endwhile;

        wp_reset_postdata();
    }

    $result = [
        'max' => $max_pages,
        'html' => $content,
        'postfound' => $found_posts,
		'count' =>$count

    ];

    echo json_encode($result);
    exit;
}

add_action('wp_ajax_reviews_load_more_posts', 'reviews_load_more_posts');
add_action('wp_ajax_nopriv_reviews_load_more_posts', 'reviews_load_more_posts');

// Function for testimonial block
function testimonial_data($youtube_id, $image, $details, $location_name, $programme_name, $learners_profile_image,$count){
	// global $youtube_id, $image, $details, $location_name, $programme_name, $learners_profile_image;
    $mobile_content = '';
	$mobile_content .= '<div class="review-item">';
		$mobile_content .='<div class="review-item-inside">';
				if($youtube_id):
					$video_url = 'https://www.youtube.com/watch?v='. $youtube_id; 
					$thumbnail_url = get_youtube_thumbnail($video_url); 
					$youtube_img=($image)?($image['url']):($thumbnail_url );
					$mobile_content .='<div class="review-main-img review-page-item-fancybox">';
						$mobile_content .='<div class="review-page-item-fancybox-image">';
							$mobile_content .='<figure>';
								$mobile_content .='<img src="'. $youtube_img .'" alt="" class="img-fluid lazy" />';
							$mobile_content .='</figure>';
						$mobile_content .='</div>';
						$mobile_content.='<a href="https://www.youtube.com/embed/'. $youtube_id .'" class="common-video-play-icon white-layout" data-fancybox="test-'.$count.'">';
							$mobile_content .='<figure>';
							$mobile_content .='<img src="'. THEME_IMG .'video-play-white-icon.svg" alt="video-play-icon" class="img-fluid lazy" />';
							$mobile_content .='</figure>';
						$mobile_content.='</a>';
					$mobile_content .='</div>';
				else:
					if($image) :
						$mobile_content .='<div class="review-main-img review-page-item-fancybox">';
							$mobile_content .='<div class="review-page-item-fancybox-image">';
								$mobile_content .='<figure>';
								$mobile_content .='<img src="' . $image['url'] .'" alt="' . $image['alt'] .'" class="img-fluid lazy" />';
								$mobile_content .='</figure>';
							$mobile_content .='</div>';        
						$mobile_content .='</div>';        
					endif;
				endif;
				if($details) :
					$mobile_content .='<div class="review-text review-text-detail">';
						$mobile_content .= $details;
					$mobile_content .='</div>';
				endif;

				if(get_the_title() || $location_name || $programme_name || $learners_profile_image) :
					$mobile_content .='<div class="review-detail">';
						$mobile_content .='<div class="reviewer">';
							if($learners_profile_image) :
								$mobile_content .='<div class="reviewer-img">';
									$mobile_content .='<img src="'. $learners_profile_image['url'] .'" alt="'. $learners_profile_image['alt'] .'" class="img-fluid" />';
								$mobile_content .='</div>';
							endif;
							if(get_the_title() || $location_name || $programme_name) :
								$mobile_content .='<div class="reviewer-detail">';
									if(get_the_title()) :
										$mobile_content .='<div class="reviewer-name">';
											$mobile_content .='<span>'. get_the_title() .'</span>';
										$mobile_content .='</div>';
									endif;
									if($location_name || $programme_name) :
										$mobile_content .='<div class="reviewer-city">';
											$mobile_content .= '<span>' . ($programme_name ? $programme_name : '') . ($location_name && $programme_name ? ', ' : '') . ($location_name ? $location_name : '') . '</span>';
										$mobile_content .='</div>';
									endif;
								$mobile_content .='</div>';
							endif;
						$mobile_content .='</div>';
					$mobile_content .='</div>';
				endif;
		$mobile_content .='</div>';
	$mobile_content .='</div>';
return $mobile_content;
}


?>