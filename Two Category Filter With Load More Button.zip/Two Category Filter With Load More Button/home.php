<?php $show_review = get_sub_field('show_review'); ?>
<?php $reviews_per_page = get_field('reviews_per_page' , 'option'); ?>
<?php if ($show_review == 'yes'):
    $args = array(
        'post_type' => 'all-testimonials',
        'post_status' => 'publish',
        'order' => 'DESC',
        'paged' => 1,
        'posts_per_page' => $reviews_per_page ? $reviews_per_page : 10,
        'tax_query' => array(
            array(
                'taxonomy' => 'display-location',
                'field' => 'slug',
                'terms' => 'blog-posts',
                'operator' => 'NOT IN',
            ),
        ),
    );

    $testmonial = new WP_Query($args);


    $args = array(
        'post_type' => 'all-testimonials',
        'post_status' => 'publish',
        'order' => 'DESC',
        'paged' => 1,
        'posts_per_page' => -1,
        'tax_query' => array(
            array(
                'taxonomy' => 'display-location',
                'field' => 'slug',
                'terms' => 'blog-posts',
                'operator' => 'NOT IN',
            ),
        ),
    );

    $select_testmonial = new WP_Query($args);
  
    $country = array();
    $programmme = array();
    $select_con = '';
    $select_pro = '';
    if ($select_testmonial->have_posts()):
        while ($select_testmonial->have_posts()):
            $select_testmonial->the_post();
            $id = get_the_ID();
            $select_country = get_field('select_country', $id);
            if ($select_country) {
                if (!in_array($select_country, $country)) {
                    $country[] = $select_country;
                    $select_con .= '<option value="' . $select_country . '">' . $select_country . '</option>';
                }
            }
            $select_programmme = get_field('select_programmme', $id);
            if ($select_programmme) {
                if (!in_array($select_programmme, $programmme)) {
                    $programmme[] = $select_programmme;
                    $select_pro .= '<option value="' . $select_programmme . '">' . $select_programmme . '</option>';
                }
            }
        endwhile;
        ?>
        <div class="review-main learner-voice learner-voice-new-grid"
            style="background: linear-gradient(255deg, rgba(2, 157, 224, 0.23) 0%, rgba(93, 212, 157, 0.23) 100%);">
            <div class="container">
                <div class="review-filter pt-5" style="display:flex; gap: 20px; justify-content: center;">
                    <div class="country-filter">
                        <?php
                        $field = get_field_object('field_661cf8fa91c9e');
                        if ($field && !empty($field['choices'])):
                            ?>
                            <select name="condition" class="form-select county-select-new" aria-label="any-condition">
                                <option value="">By Country</option>
                                <?php if ($select_con): ?>
                                    <?php echo $select_con; ?>
                                <?php endif; ?>
                            </select>
                        <?php endif; ?>
                    </div>
                    <div class="programme-filter">
                        <?php
                        $field = get_field_object('field_661cf90c91c9f');
                        if ($field && !empty($field['choices'])):
                            ?>
                            <select name="condition" class="form-select program-select-new" aria-label="any-condition">
                                <option value="">By Programme</option>
                                <?php if ($select_pro): ?>
                                    <?php echo $select_pro; ?>
                                <?php endif; ?>
                            </select>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="review-section">
                    <div class="review-list-grid">
                        <?php $count = 1;
                        while ($testmonial->have_posts()):
                            $testmonial->the_post(); ?>
                            <?php $id = get_the_ID(); ?>
                            <?php
                            $image = get_field('image_video_image', $id);
                            $youtube_id = get_field('youtube_id', $id);
                            $location_name = get_field('location_name', $id);
                            $programme_name = get_field('programme_name', $id);
                            $details = get_field('details', $id);
                            $learners_profile_image = get_field('learners_profile_image', $id);
                            ?>
                            <?php if ($image || $youtube_id || $details || $location_name || $learners_profile_image || $programme_name): ?>
                                <?php echo testimonial_data($youtube_id, $image, $details, $location_name, $programme_name, $learners_profile_image, $count); ?>
                            <?php endif; ?>
                            <?php ?>
                            <?php $count++; endwhile; ?>

                        <?php wp_reset_postdata(); ?>

                    </div>
                    <div class="container">
                        <div class="load-more-button text-center">
                            <a href="javascript:void(0)" id="custom-load-more" class="btn btn-simple-sky load-more-review-btn">Load More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<script>

(function ($) {
    $(document).ready(function () {
        var $container = $('.learner-voice-new-grid .review-list-grid').isotope({
            // layoutMode: 'packery',
            itemSelector: '.learner-voice-new-grid .review-item',
            masonry: {
            gutter: 30
            }
        });

        var initShow = <?php echo $reviews_per_page ?>; //number of items loaded on init & onclick load more button
        var counter = initShow; //counter for load more button
        var iso = $container.data('isotope'); // get Isotope instance

        // loadMore(initShow); //execute function onload

        // function loadMore(toShow) {
        //     $container.find(".d-none").removeClass("d-none");

        //     var hiddenElems = iso.filteredItems.slice(toShow, iso.filteredItems.length).map(function (item) {
        //         return item.element;
        //     });
        //     $(hiddenElems).addClass('d-none');
        //     $container.isotope('layout');

        //     //when no more to load, hide show more button
        //     if (hiddenElems.length == 0) {
        //         jQuery("#custom-load-more").hide();
        //     } else {
        //         jQuery("#custom-load-more").show();
        //     };
        // }

        // //when load more button clicked
        // $("#custom-load-more").click(function () {
          
        //     counter = counter + initShow;
        //     loadMore(counter);
        // });

    });
})(jQuery);


</script>