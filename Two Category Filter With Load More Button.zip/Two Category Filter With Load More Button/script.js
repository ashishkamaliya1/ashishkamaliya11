(function ($) {
    // Insights Page Filtering Loop Posts AJAX
    $(document).ready(function () {
        var reviews_per_page = acfFieldData.reviews_per_page;
        var ajaxurl = frontendajax.ajaxurl;
        var val1 = '';
        var val2 = '';
        var page = 1;
        var isLoading = false;

        // Function to load posts
        function loadMorePosts(reset = false) {
            if (isLoading) return;
            isLoading = true;

            if (reset) {
                $('.review-section .review-list-grid').html('');
                page = 1;
            }

            $.ajax({
                type: 'post',
                url: ajaxurl,
                data: {
                    action: 'reviews_load_more_posts',
                    page: page,
                    id1: val1,
                    id2: val2,
                    loop_posts_per_page_loop: reviews_per_page,
                },
                success: function (response) {
                    var data = JSON.parse(response);
                    var noPostsMessage = '<div class="no-posts-message">No reviews found.</div>';

                    if (reset) {
                        $('.review-section .review-list-grid').html('');
                    }

                    if (data.html === '') {
                        $('#custom-load-more').hide();
                        if (reset) {
                            $('.review-section .review-list-grid').html(noPostsMessage);
                        }
                    } else {
                        // $('.learner-voice-new-grid .review-list-grid').isotope('destroy');
                        $('.review-section .review-list-grid').append(data.html);
                        setTimeout(function () {

                            var $container = jQuery('.learner-voice-new-grid .review-list-grid');
                            $container.isotope('appended', data.html);
                            $container.isotope("reloadItems").isotope();
                            // $container.imagesLoaded().progress(function ()
                            // {
                            //     $container.isotope("reloadItems").isotope();
                            // });
            
                            
                        }, 50);
                    }

                    $('#custom-load-more').removeAttr('disabled').text('Load More');
                    if (page >= data.max) {
                        $('#custom-load-more').hide();
                    } else {
                        $('#custom-load-more').show();
                    }
                    isLoading = false;
                },
                error: function () {
                    $('#custom-load-more').removeAttr('disabled').text('Load More');
                    isLoading = false;
                }
            });
        }


        // Click event for "Load More" button
        $('#custom-load-more').on('click', function (e) {
            e.preventDefault();

            if (isLoading) return;

            $(this).attr('disabled', 'disabled').text('Loading...');
            page++;
            loadMorePosts();
        });

        // Change event for filter dropdowns
        $('.county-select-new').on('change', function () {
            val1 = $(this).val();
            loadMorePosts(true);
        });

        $('.program-select-new').on('change', function () {
            val2 = $(this).val();
            loadMorePosts(true);
        });
    });




})(jQuery);
