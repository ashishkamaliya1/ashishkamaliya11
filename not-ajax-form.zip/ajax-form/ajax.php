<?php



require_once get_template_directory() . '/assets/smtp/PHPMailerAutoload.php';


// Handle the AJAX form submission
function handle_contact_form_submission() {
    // Verify the nonce for security
    if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'contact_form_nonce')) {
        wp_send_json_error('Nonce verification failed!');
        wp_die();
    }

    // Check if the form was submitted via POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Sanitize form fields
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $email = sanitize_email($_POST['email_address']);
        $website = sanitize_text_field($_POST['website_name']);
        $message = sanitize_textarea_field($_POST['message']);

        // Handle file upload for PDF and image
        $pdf_file = $_FILES['pdf_file'];
        $image_file = $_FILES['image_file'];

        // File upload handling
        $upload_dir = wp_upload_dir();
        $pdf_file_path = wp_handle_upload($pdf_file, array('test_form' => false));
        $image_file_path = wp_handle_upload($image_file, array('test_form' => false));

        if (isset($pdf_file_path['error']) || isset($image_file_path['error'])) {
            wp_send_json_error('File upload failed');
            wp_die();
        }

        // Generate thumbnail for image file
    

            // Generate thumbnail for image file
$image_id = attachment_url_to_postid($image_file_path['url']);
$thumbnail = wp_get_attachment_image_src($image_id, 'thumbnail')[0];

// Prepare the email message
$msg = "First Name: $first_name<br>";
$msg .= "Last Name: $last_name<br>";
$msg .= "Email: $email<br>";
$msg .= "Website: $website<br>";
$msg .= "Message: $message<br>";
$msg .= "PDF File: <a href='" . $pdf_file_path['url'] . "'>Download PDF</a><br>";

// Image File Link and Image Display
$msg .= "Image File: <a href='" . $image_file_path['url'] . "'>Download Image</a><br>";
$msg .= "Image Display: <img src='" . $image_file_path['url'] . "' alt='Uploaded Image'><br>";

// Image Thumbnail Display
$msg .= "Image Thumbnail: <img src='" . $thumbnail . "' alt='Image Thumbnail'>";


        // Send email using PHPMailer or wp_mail
        $sent = smtp_mailer('ashishkamaliya187@gmail.com', 'New Contact Form Submission', $msg);

        if ($sent) {
            wp_send_json_success('Form submitted successfully!');
        } else {
            wp_send_json_error('Failed to send email.');
        }

        wp_die();
    }
}
add_action('wp_ajax_nopriv_handle_contact_form', 'handle_contact_form_submission'); // Non-logged-in users
add_action('wp_ajax_handle_contact_form', 'handle_contact_form_submission'); // Logged-in users

// Function to send email using PHPMailer
function smtp_mailer($to, $subject, $msg) {
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587;
    $mail->IsHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Username = "ashishkamaliya187@gmail.com";
    $mail->Password = "jdbzwexubfqamyjp";
    $mail->SetFrom("ashishkamaliya1@gmail.com");
    $mail->Subject = $subject;
    $mail->Body = nl2br($msg); // Convert newlines to <br> for HTML formatting
    $mail->AddAddress($to);

    // Set SMTP options to avoid SSL issues
    $mail->SMTPOptions = array(
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        )
    );

    if (!$mail->Send()) {
        return false;
    } else {
        return true;
    }
}
