<?php 
get_header();

/* Template Name:Home Page */ 
?>

<?php $social_media_details=get_field( 'social_media_details','option' ); ?>
			<?php $select_product_left_side=get_field( 'select_product_left_side' ); ?>
			<!-- SLIDER-BANNER-AREA START -->
			 <?php $select_product=get_field( 'select_product' ); ?>
			 <?php $b_welcome_title=get_field( 'b_welcome_title' ); ?>
			 <?php $b_main_title=get_field( 'b_main_title' ); ?>
			 <?php $b_sub_title=get_field( 'b_sub_title' ); ?>
			<section class="slider-banner-area clearfix">
				<!-- Sidebar-social-media start -->
				<?php if($social_media_details): ?>
					<div class="sidebar-social d-none d-md-block">
						<div class="table">
							<div class="table-cell">
								<ul>
									<?php foreach($social_media_details as $social_media_del): ?>
										<?php $social_icon=$social_media_del['social_icon']; ?>
										<?php $social_media_link=$social_media_del['social_media_link']; ?>
										<?php if($social_media_link): ?>
											<li><a href="<?php echo $social_media_link ?>" target="_blank" title="Google Plus"><?php echo 	$social_icon ?></a></li>
										<?php endif; ?>
									<?php endforeach;; ?>
								</ul>
							</div>
						</div>
					</div>
				<?php endif; ?>
				<!-- Sidebar-social-media start -->
				 <?php if($select_product_left_side): ?>
					<div class="banner-left floatleft">
						<!-- Slider-banner start -->
						<div class="slider-banner">
							<?php $i=1; foreach($select_product_left_side as $post): ?>
							<?php setup_postdata($post); ?>
							<?php $thumbnail = (get_the_post_thumbnail_url()) ? get_the_post_thumbnail_url() : DEFAULT_IMG; ?>
							<?php 
							 $categories = get_the_category();
							 $category_name = !empty($categories) ? esc_html($categories[0]->name) : 'Uncategorized'; // Fallback to 'Uncategorized' if no category
							?>
							<?php $product_new=get_field('product_new'); ?>
							<?php $product_price=get_field('product_price'); ?>
							<div class="single-banner banner-<?php echo $i; ?>">
								<a class="banner-thumb" href="<?php echo get_the_permalink() ?>"><img src="<?php echo $thumbnail; ?>" alt=""></a>
								<?php if($product_new=='New'){ ?>
								<span class="pro-label new-label">new</span>
								<?php }else{ ?>
									<span class="pro-label new-label">old</span>
								<?php }; ?>
								<span class="price"><?php echo $product_price; ?></span>
								<div class="banner-brief">
								
									
								</div>
								
							</div>
							<?php $i++; endforeach; wp_reset_postdata(); ?>
						</div>
						<!-- Slider-banner end -->
					</div>
				<?php endif; ?>
				<div class="slider-right floatleft">
					<!-- Slider-area start -->
					<div class="slider-area">
						<div class="bend niceties preview-2">
							<div id="ensign-nivoslider" class="slides">
								<img src="<?php echo THEME_IMG ?>/1_2.jpg" alt="" title="#slider-direction-1">
								<img src="<?php echo THEME_IMG ?>/2_2.jpg" alt="" title="#slider-direction-2">
								<img src="<?php echo THEME_IMG ?>/3.jpg" alt="" title="#slider-direction-3">
							</div>
							<!-- direction 1 -->
							<div id="slider-direction-1" class="t-cn slider-direction">
								<div class="slider-progress"></div>
								<div class="slider-content t-lfl s-tb slider-1">
									<div class="title-container s-tb-c title-compress">
										<div class="layer-1">
											<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
												<h2 class="slider-title3 text-uppercase mb-0">welcome to our</h2>
											</div>
											<div class="wow fadeIn" data-wow-duration="1.5s" data-wow-delay="1.5s">
												<h2 class="slider-title1 text-uppercase mb-0">furniture</h2>
											</div>
											<div class="wow fadeIn" data-wow-duration="2s" data-wow-delay="2.5s">
												<h3 class="slider-title2 text-uppercase">gallery 2021</h3>
											</div>
											<div class="wow fadeIn" data-wow-duration="2.5s" data-wow-delay="3.5s">
												<a href="#" class="button-one style-2 text-uppercase mt-20" data-text="Shop now">Shop now</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						
						
						</div>
					</div>
					<!-- Slider-area end -->
				</div>
				<!-- Sidebar-social-media start -->
				<!-- <div class="sidebar-account d-none d-md-block">
					<div class="table">
						<div class="table-cell">
							<ul>
								<li><a class="search-open" href="#" title="Search"><i class="zmdi zmdi-search"></i></a></li>
								<li><a href="#" title="Login"><i class="zmdi zmdi-lock"></i></a>
									<div class="customer-login text-left">
										<form action="#">
											<h4 class="title-1 title-border text-uppercase mb-30">Registered customers</h4>
											<p class="text-gray">If you have an account with us, Please login!</p>
											<input type="text" name="email" placeholder="Email here...">
											<input type="password" placeholder="Password">
											<p><a class="text-gray" href="#">Forget your password?</a></p>
											<button class="button-one submit-button mt-15" data-text="login" type="submit">login</button>
										</form>
									</div>
								</li>
								<li><a href="my-account.html" title="My-Account"><i class="zmdi zmdi-account"></i></a></li>
								<li><a href="wishlist.html" title="Wishlist"><i class="zmdi zmdi-favorite"></i></a></li>
							</ul>
						</div>
					</div>
				</div> -->
				<!-- Sidebar-social-media start -->
			</section>
			<!-- End Slider-section -->
			<!-- sidebar-search Start -->
			<!-- <div class="sidebar-search animated slideOutUp">
				<div class="table">
					<div class="table-cell">
						<div class="container">
							<div class="row">
								<div class="col-md-8 offset-md-2 p-0">
									<div class="search-form-wrap">
										<button class="close-search"><i class="zmdi zmdi-close"></i></button>
										<form action="#">
											<input type="text" placeholder="Search here...">
											<button class="search-button" type="submit">
												<i class="zmdi zmdi-search"></i>
											</button>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div> -->
			<!-- sidebar-search End -->
			<!-- PRODUCT-AREA START -->
			 <?php $select_product=get_field( 'select_product' ); ?>
			 <?php $f_main_title=get_field( 'f_main_title' ); ?>
			 <?php if($select_product): ?>
				<div class="product-area pt-80 pb-35">
					<div class="container">
						<div class="row">
							<div class="col-lg-12">
								<?php if($f_main_title): ?>
									<div class="section-title text-center">
										<h2 class="title-border"><?php echo $f_main_title; ?></h2>
									</div>
								<?php endif; ?>
								<div class="product-slider style-1 arrow-left-right">
									<!-- Single-product start -->
									<?php foreach($select_product as $post): ?>
										<?php setup_postdata($post) ?>
										<?php $thumbnail = (get_the_post_thumbnail_url()) ? get_the_post_thumbnail_url() : DEFAULT_IMG; ?>
										<?php $product_new=get_field('product_new'); ?>
										<?php $product_price=get_field('product_price'); ?>
										<?php $product_rating=get_field('product_rating'); ?>
										<div class="single-product">
											<div class="product-img">
												<?php if($select_product): ?>
													<?php if($select_product == 'New'){ ?>
													<span class="pro-label new-label">New</span>
													<?php } else{ ?>
														<span class="pro-label new-label">Old</span>

													<?php }; ?>
												<?php endif; ?>
												<a href="<?php echo get_the_permalink(); ?>"><img src="<?php echo $thumbnail; ?>"alt=""></a>
												<div class="product-action clearfix">

												</div>
											</div>
											<div class="product-info clearfix">
												<div class="fix">
													<h4 class="post-title floatleft"><a href="#"><?php echo get_the_title($post); ?></a></h4>
													<p class="floatright hidden-sm d-none d-md-block">Furniture</p>
												</div>
												<div class="fix">
													<span class="pro-price floatleft"><?php echo $product_price; ?></span>
													<span class="pro-rating floatright">
														<?php for ($i=0; $i <$product_rating; $i++) { 
															# code...
															echo '<a href="#"><i class="zmdi zmdi-star"></i></a>';
														} ?>
													</span>
												</div>
											</div>
										</div>
									<?php endforeach; wp_reset_postdata();?>
									<!-- Single-product end -->

								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<!-- PRODUCT-AREA END -->
			<!-- DISCOUNT-PRODUCT START -->
			 <?php $slider_details=get_field( 'slider_details' ); ?>
			 <?php if($slider_details): ?>
				<div class="discount-product-area">
					<div class="container">
						<div class="row">
							<div class="discount-product-slider dots-bottom-right">
								<!-- single-discount-product start -->
								 <?php foreach($slider_details as $slider_del): ?>
									<?php $background_image=$slider_del['background_image']; ?>
									<?php $discount_title=$slider_del['discount_title']; ?>
									<?php $is_on_sale=$slider_del['is_on_sale']; ?>
									<?php $price=$slider_del['price']; ?>
									<?php $short_description=$slider_del['short_description']; ?>
									<?php $button=$slider_del['button']; ?>
									<div class="col-lg-12">
										<div class="discount-product">
											<img src="<?php echo $background_image['url']; ?>" alt="">
											<div class="discount-img-brief">
												<div class="onsale">
													<?php if($is_on_sale=='Yes'): ?>
														<span class="onsale-text">On Sale</span>
													<?php endif; ?>
													<span class="onsale-price"><?php echo $price; ?></span>
												</div>
												<div class="discount-info">
													<h1 class="text-dark-red d-none d-md-block"><?php echo $discount_title; ?></h1>
													<p class="d-none d-md-block"><?php echo $short_description ?></p>
													<?php if($button): ?>
													<a href="<?php echo $button['url']; ?>" target="<?php echo $button['target']; ?>" class="button-one font-16px style-3 text-uppercase mt-md-5" data-text="Buy now"><?php echo $button['title']; ?></a>
													<?php endif; ?>
												</div>
											</div>
										</div>
									</div>
								<?php endforeach; ?>
								<!-- single-discount-product end -->
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<!-- DISCOUNT-PRODUCT END -->
			<!-- PURCHASE-ONLINE-AREA START -->
			 <?php $c_main_title=get_field( 'c_main_title' ); ?>
			 <?php $product_terms = get_field('select_category'); ?>
			<div class="purchase-online-area pt-80">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="section-title text-center">
								<h2 class="title-border"><?php echo $c_main_title; ?></h2>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12 text-center">
							<!-- Nav tabs -->
							<ul class="tab-menu nav clearfix">
								<li><a class="" data-category="all" >All Category</a></li>
							<?php foreach( $product_terms as $term ): ?>
								
								<li><a class="" data-category="<?php echo $term->slug; ?>" data-bs-toggle="tab"><?php echo $term->name ?></a></li>
							<?php endforeach; ?>
							</ul>
						</div>
						<div class="col-lg-12">
							<!-- Tab panes -->
							<div class="tab-content">

								<div class="tab-pane active" id="new-arrivals">
									<div class="row append-content-row">

									</div>
								</div>

							</div>

						</div>
					</div>
				</div>
			</div>
			<!-- PURCHASE-ONLINE-AREA END -->
			<!-- BLGO-AREA START -->
			 <?php $select_blog=get_field( 'select_blog' ); ?>
			 <?php if($select_blog): ?>
				<div class="blog-area pt-55">
					<div class="container">
						<!-- Section-title start -->
						<div class="row">
							<div class="col-lg-12">
								<div class="section-title text-center">
									<h2 class="title-border">From The Blog</h2>
								</div>
							</div>
						</div>
						<!-- Section-title end -->
						<div class="row">
							<?php foreach($select_blog as $post): ?>
								<?php  setup_postdata($post); ?>
								<?php $thumbnail = (get_the_post_thumbnail_url()) ? get_the_post_thumbnail_url() : DEFAULT_IMG; ?>
								<div class="col-lg-6">
									<div class="single-blog mt-30">
										<div class="row">
											<div class="col-xl-6 col-md-7">
												<div class="blog-info">
													<div class="post-meta fix">
														<div class="post-date floatleft"><span class="text-dark-red"><?php echo get_the_date('d') ?></span></div>
														<div class="post-year floatleft">
															<p class="text-uppercase text-dark-red mb-0"><?php echo get_the_date('"F, Y"') ?></p>
															<h4 class="post-title"><a href="#" tabindex="0">Farniture drawing 2021</a></h4>
														</div>
													</div>
													<div class="like-share fix">
															<!-- <a href="#"><i class="zmdi zmdi-favorite"></i><span>89 Like</span></a>
															<a href="#"><i class="zmdi zmdi-comments"></i><span>59 Comments</span></a>
															<a href="#"><i class="zmdi zmdi-share"></i><span>29 Share</span></a> -->
													</div>
													<p><?php echo get_the_excerpt() ?></p>
													<a href="<?php echo get_the_permalink() ?>" class="button-2 text-dark-red">Read more...</a>
												</div>
											</div>
											<div class="col-xl-6 col-md-5">
												<div class="blog-photo">
													<a href="<?php echo get_the_permalink() ?>"><img src="<?php echo $thumbnail
													 ?>" alt=""></a>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endforeach; wp_reset_postdata();?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<!-- BLGO-AREA END -->
			<!-- SUBSCRIVE-AREA START -->
			<div class="subscribe-area pt-80">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="subscribe">
								<form action="#">
									<input type="text" placeholder="Enter your email address">
									<button class="submit-button submit-btn-2 button-one" data-text="subscribe" type="submit">subscribe</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- SUBSCRIVE-AREA END -->


<script type="text/javascript">

      

(function($){
    jQuery(document).ready(function($) {
        // Load all products initially
        loadProducts('all');

        $('.tab-menu a ').on('click', function(e) {
            e.preventDefault();
            
            var category = $(this).attr('data-category');
            loadProducts(category); // Call the function to load products based on category
        });

        function loadProducts(category) {
            var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'filter_products',
                    category: category
                },
                beforeSend: function() {
                    $('.append-content-row').html('<div class="loader">Loading...</div>'); // Show loader
                },
                success: function(response) {
					// alert(response);
                    $('.append-content-row').html(response); // Replace content with products
                },
                error: function() {
                    $('.append-content-row').html('<div class="error">An error occurred. Please try again.</div>');
                }
            });
        }
    });
})(jQuery);

</script>
<?php get_footer(); ?>